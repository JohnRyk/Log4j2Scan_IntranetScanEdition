package burp.ui.tabs;

import burp.BurpExtender;
import burp.utils.Config;
import burp.utils.UIUtil;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.util.ArrayList;

public class BackendUIHandler {
    public enum Backends {
         InternalDnslog
    }

    private BurpExtender parent;
    private JPanel mainPanel;

    public JTabbedPane backendsPanel;
    private JComboBox<String> backendSelector;

    private JTextField internalDnslogUrlInput;

    private Insets buttonMargin = new Insets(0, 3, 0, 3);


    public BackendUIHandler(BurpExtender parent) {
        this.parent = parent;
    }

    public JPanel getPanel() {
        mainPanel = new JPanel();
        mainPanel.setAlignmentX(0.0f);
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.setLayout(new BoxLayout(mainPanel, 1));
        JPanel panel1 = UIUtil.GetXJPanel();
        backendSelector = new JComboBox(GetBackends());
        backendSelector.setMaximumSize(backendSelector.getPreferredSize());
        backendSelector.setSelectedIndex(0);

        JButton applyBtn = new JButton("Apply");
        applyBtn.setMaximumSize(applyBtn.getPreferredSize());
        applyBtn.addActionListener(e -> {
            Config.set(Config.CURRENT_BACKEND, backendSelector.getSelectedItem().toString());
            this.apply();
        });
        applyBtn.setMargin(buttonMargin);
        panel1.add(new JLabel("Use backend: "));
        panel1.add(backendSelector);
        panel1.add(applyBtn);

        JPanel panel2 = UIUtil.GetXJPanel();
        backendsPanel = new JTabbedPane();
        backendsPanel.addTab("InternalDnslog", getInternalDNSlogPanel());
        panel2.add(backendsPanel);

        mainPanel.add(panel1);
        mainPanel.add(panel2);
        loadConfig();
        return mainPanel;
    }

    private void apply() {
        parent.reloadScanner();
        if (parent.scanner.getState()) {
            JOptionPane.showMessageDialog(mainPanel, "Apply success!");
        } else {
            JOptionPane.showMessageDialog(mainPanel, "Apply failed, please go to plug-in log see detail!");
        }
    }

    private JPanel getInternalDNSlogPanel() {
        JPanel panel1 = new JPanel();
        panel1.setAlignmentX(0.0f);
        panel1.setBorder(new EmptyBorder(10, 10, 10, 10));
        panel1.setLayout(new BoxLayout(panel1, 1));

        JPanel subPanel1 = UIUtil.GetXJPanel();
        internalDnslogUrlInput = new JTextField(200);
        internalDnslogUrlInput.setMaximumSize(internalDnslogUrlInput.getPreferredSize());
        subPanel1.add(new JLabel("Internal DNSlog URL: "));
        subPanel1.add(internalDnslogUrlInput);

        JPanel subPanel2 = UIUtil.GetXJPanel();
        JButton saveBtn = new JButton("Save");
        saveBtn.setMaximumSize(saveBtn.getPreferredSize());
        saveBtn.addActionListener(e -> {
            Config.set(Config.INTERNAL_DNSLOG_URL, internalDnslogUrlInput.getText());
            JOptionPane.showMessageDialog(mainPanel, "Save success!");
        });
        JButton applyBtn = new JButton("Save&Apply");
        applyBtn.setMaximumSize(applyBtn.getPreferredSize());
        applyBtn.addActionListener(e -> {
            saveBtn.doClick();
            Config.set(Config.CURRENT_BACKEND, Backends.InternalDnslog.name());
            this.loadConfig();
            this.apply();
        });
        saveBtn.setMargin(buttonMargin);
        applyBtn.setMargin(buttonMargin);
        subPanel2.add(saveBtn);
        subPanel2.add(applyBtn);

        panel1.add(subPanel1);
        panel1.add(subPanel2);
        return panel1;
    }


    private void loadConfig() {
        backendSelector.setSelectedItem(Config.get(Config.CURRENT_BACKEND, Backends.InternalDnslog.name()));
    }

    private String[] GetBackends() {
        ArrayList<String> algStrs = new ArrayList<String>();
        Backends[] backends = Backends.values();
        for (Backends backend : backends) {
            algStrs.add(backend.name().replace('_', '/'));
        }
        return algStrs.toArray(new String[algStrs.size()]);
    }
}
