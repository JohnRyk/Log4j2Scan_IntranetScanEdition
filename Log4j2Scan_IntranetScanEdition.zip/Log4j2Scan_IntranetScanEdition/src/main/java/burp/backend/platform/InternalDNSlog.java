package burp.backend.platform;

import burp.backend.IBackend;
import burp.poc.IPOC;
import burp.utils.Config;
import burp.utils.HttpUtils;
import burp.utils.Utils;
import okhttp3.*;

import java.util.*;
import java.util.concurrent.TimeUnit;

import static burp.utils.HttpUtils.GetDefaultRequest;

public class InternalDNSlog implements IBackend {
    OkHttpClient client = new OkHttpClient().newBuilder().cookieJar(new CookieJar() {
                private final HashMap<String, List<Cookie>> cookieStore = new HashMap<>();

                @Override
                public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                    cookieStore.put(url.host(), cookies);
                }

                @Override
                public List<Cookie> loadForRequest(HttpUrl url) {
                    List<Cookie> cookies = cookieStore.get(url.host());
                    return cookies != null ? cookies : new ArrayList<Cookie>();
                }
            }).connectTimeout(50, TimeUnit.SECONDS).
            callTimeout(50, TimeUnit.SECONDS).
            readTimeout(3, TimeUnit.MINUTES).build();


    //String platformUrl = "http://172.17.0.1:18888/";
    String platformUrl = "";
    String rootDomain = "";
    String dnsLogResultCache = "";
    Timer timer = new Timer();

    public InternalDNSlog() {
        this.platformUrl = Config.get(Config.INTERNAL_DNSLOG_URL);
        this.initDomain();
    }

    private void initDomain() {
        try {
            Utils.Callback.printOutput("get domain...");
            Response resp = client.newCall(GetDefaultRequest(platformUrl + "/getdomain.php?t=0." + Math.abs(Utils.getRandomLong())).build()).execute();
            rootDomain = resp.body().string();
            Utils.Callback.printOutput(String.format("Domain: %s", rootDomain));
            startSessionHeartbeat();
        } catch (Exception ex) {
            Utils.Callback.printError("initDomain failed: " + ex.getMessage());
        }
    }

    private void startSessionHeartbeat() {
        /**
         timer.schedule(new TimerTask() {
        @Override
        public void run() {
        flushCache();
        }
        }, 0, 2 * 60 * 1000); //2min
         **/
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                flushCache();
            }
        }, 0, 1 * 6 * 1000); // 6 second
    }

    @Override
    public void close() {
        timer.cancel();
    }

    @Override
    public String getName() {
        return "Dnslog.cn";
    }

    @Override
    public String getNewPayload() {
        //return Utils.getCurrentTimeMillis() + Utils.GetRandomString(5) + "." + rootDomain;
        //return rootDomain + "/" + Utils.getCurrentTimeMillis() + '/' + Utils.GetRandomString(5) + "/${hostName}-${sys:user.dir}-${sys:java.version}-${java:os}";
        return String.format("%s" , rootDomain + "/00000000/" +  Utils.GetRandomString(5) + "/${hostName}");
        //return rootDomain + "/" + Utils.getCurrentTimeMillis() + '/' + Utils.GetRandomString(5) + "/${hostName}";
    }


    public boolean flushCache() {
        try {
            Response resp = client.newCall(HttpUtils.GetDefaultRequest(platformUrl + "getrecords.php?t=0." + Math.abs(Utils.getRandomLong())).build()).execute();
            dnsLogResultCache = resp.body().string().toLowerCase();
            Utils.Callback.printOutput(String.format("Got Dnslog Result OK!: %s", dnsLogResultCache));
            return true;
        } catch (Exception ex) {
            Utils.Callback.printOutput(String.format("Get Dnslog Result Failed!: %s", ex.getMessage()));
            return false;
        }
    }

    @Override
    public boolean flushCache(int count) {
        return flushCache();
    }

    @Override
    public boolean CheckResult(String domain) {
        //return dnsLogResultCache.contains(domain.toLowerCase());
        return dnsLogResultCache.contains(domain.toLowerCase().split("/")[2]);
        //return dnsLogResultCache.contains(domain.toLowerCase().split("/")[0]);
    }

    @Override
    public boolean getState() {
        return rootDomain != "";
    }

    @Override
    public int[] getSupportedPOCTypes() {
        return new int[]{IPOC.POC_TYPE_DNS};
    }
}
